# Cookie-Clicker-Source-Code
2.021 source code for... educational purposes... <br>
Download and Extract to delete free time. Or just use the website. <br> <br>
Do not worry, I will be updating this to be up to date with the current Cookie Clicker version. <br>
<!-- Well guess what, 2.021 came out... what happened to 2.020??  -->
Credits obviously go Orteil, visit the official website here: http://orteil.dashnet.org/cookieclicker/
